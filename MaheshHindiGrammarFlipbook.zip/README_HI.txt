महेश शर्मा — हिंदी व्याकरण एवं काव्यशास्त्र फ्लिपबुक

यह Android Studio प्रोजेक्ट उपयोगकर्ता द्वारा अपलोड की गई 23 पृष्ठों की PDF के हर पृष्ठ को ऐप में ऑफलाइन चित्र के रूप में रखता है।
ऐप में स्वाइप और पिछले/अगले बटन से पृष्ठ बदले जा सकते हैं।
इंटरनेट/Chrome की जरूरत ऐप के भीतर किताब पढ़ने के लिए नहीं होगी।

APK अभी compile नहीं हुआ है। GitHub Actions workflow `.github/workflows/build-apk.yml` शामिल है।
प्रोजेक्ट ZIP को `MaheshHindiGrammarFlipbook.zip` नाम से Repository के root में upload करें और workflow को Actions tab से manually चलाएँ।
